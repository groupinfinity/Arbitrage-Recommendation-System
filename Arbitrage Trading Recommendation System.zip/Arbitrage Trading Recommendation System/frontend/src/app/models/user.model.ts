export interface User{
    checked:boolean;
    rank: String;
    companyName: String;
    nse: Number;
    bse: Number;
    pricediff: Number;
    buy: String;
    highlighted?: boolean;
    hovered?: boolean;
  
    
}