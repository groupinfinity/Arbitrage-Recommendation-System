import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-savestock',
  templateUrl: './savestock.component.html',
  styleUrls: ['./savestock.component.css']
})
export class SavestockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
